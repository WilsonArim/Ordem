# PIPELINE TOC

## M01-exemplo 
- [E01-exemplo-etapa ](./modulos/M01-exemplo/etapas/E01-exemplo-etapa/E01.md)
  - [T001-exemplo ](./modulos/M01-exemplo/etapas/E01-exemplo-etapa/tarefas/T001-exemplo/T001.md)

## M02-autenticacao (TODO)
- [E01-base-tokens (TODO)](./modulos/M02-autenticacao/etapas/E01-base-tokens/E01.md)
  - [T001-endpoint-login (TODO)](./modulos/M02-autenticacao/etapas/E01-base-tokens/tarefas/T001-endpoint-login/T001.md)

