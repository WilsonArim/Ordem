ID: YYYY-MM-DD-XXX
TÍTULO: <título do capítulo>
STATUS: TODO
OWNER: <nome/equipa>
PROJETO: <ex.: Viriato>
DEPENDÊNCIAS: []
LINKS: []

## DESCRIÇÃO
Breve explicação do objetivo deste capítulo.

## SUBMÓDULOS / ETAPAS
Liste as etapas associadas (geradas automaticamente no TOC).

## NOTAS
Observações relevantes (riscos, constraints, tech stack).