ID: YYYY-MM-DD-XXX
TÍTULO: <título da etapa>
STATUS: TODO
OWNER: <nome/equipa>
PROJETO: <ex.: Viriato>
CAPITULO_PAI: Mxx
DEPENDÊNCIAS: []
LINKS: []

## DESCRIÇÃO
Breve explicação do objetivo desta etapa.

## TAREFAS
As tarefas desta etapa estarão listadas no TOC.

## NOTAS
Observações relevantes (riscos locais, blockers).