ID: YYYY-MM-DD-XXX
TÍTULO: <título da tarefa>
STATUS: TODO
OWNER: <nome/equipa>
PROJETO: <ex.: Viriato>
CAPITULO_PAI: Mxx
ETAPA_PAI: Eyy
ENTRADAS: <artefactos/decisões necessárias>
SAÍDAS: <artefactos gerados (patches, docs)>
DEPENDÊNCIAS: []
LINKS: []

## CRITÉRIOS (mín. 2)
- [ ] Critério 1 (mensurável)
- [ ] Critério 2 (mensurável)

## PLAN
Passos concretos que serão executados.

## PATCH
Resumo do que foi alterado/criado (caminhos, ficheiros, diffs).

## TESTS
Como foi validado (comandos, outputs, prints de CI, etc.).

## SELF-CHECK
- [ ] Critérios cumpridos
- [ ] Gatekeeper executado conforme ordem
- [ ] RELATORIO.MD ATUALIZADO